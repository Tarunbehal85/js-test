// Health data
const healthData = [
    {
      name: "rahul",
      age: 30,
      height: 175,
      weight: 75,
      bmi: 24.5,
      bloodPressure: [120, 80],
      cholesterol: 200,
      bloodSugar: 100,
      heartRate: 70,
    },
    {
      name: "Tarun",
      age: 25,
      height: 165,
      weight: 60,
      bmi: 22.0,
      bloodPressure: [110, 70],
      cholesterol: 180,
      bloodSugar: 90,
      heartRate: 60,
    },
    {
      name: "Chandan",
      age: 40,
      height: 180,
      weight: 85,
      bmi: 26.1,
      bloodPressure: [130, 90],
      cholesterol: 220,
      bloodSugar: 110,
      heartRate: 80,
    },
  ];
  
  function drawChartsForAllFields(data) {
    const fields = Object.keys(data[0]).filter((key) => key !== "name");
  
    const container = document.createElement("div");
    container.style.display = "flex";
    container.style.flexWrap = "wrap";
    document.body.appendChild(container);
  
    const colors = [
      "rgba(255, 99, 132, 1)",
      "rgba(54, 162, 235, 1)",
      "rgba(255, 206, 86, 1)",
      "rgba(75, 192, 192, 1)",
      "rgba(153, 102, 255, 1)",
      "rgba(255, 159, 64, 1)",
    ];
  
    drawCombinedBarChart(data, fields, container, colors);
    drawLineChart(data, fields, container, colors);
    drawPieChart(data, fields, container, colors);
  }
  
  function drawCombinedBarChart(data, fields, container, colors) {
    const canvas = document.createElement("canvas");
    canvas.width = 800;
    canvas.height = 600;
    container.appendChild(canvas);
  
    const ctx = canvas.getContext("2d");
  
    new Chart(ctx, {
      type: "bar",
      data: {
        labels: data.map((item) => item.name),
        datasets: fields.map((fieldName, index) => ({
          label: fieldName,
          data: data.map((item) => item[fieldName]),
          backgroundColor: colors[index % colors.length],
          borderColor: "rgba(0, 0, 0, 1)",
          borderWidth: 1,
        })),
      },
      options: {
        scales: {
          y: {
            beginAtZero: true,
          },
        },
        responsive: true,
        maintainAspectRatio: false,
        plugins: {
          title: {
            display: true,
            text: "Bar Chart",
          },
        },
      },
    });
  }
  
  function drawLineChart(data, fields, container, colors) {
    const canvas = document.createElement("canvas");
    canvas.width = 800;
    canvas.height = 600;
    container.appendChild(canvas);
  
    const ctx = canvas.getContext("2d");
  
    new Chart(ctx, {
      type: "line",
      data: {
        labels: data.map((item) => item.name),
        datasets: fields.map((fieldName, index) => ({
          label: fieldName,
          data: data.map((item) => item[fieldName]),
          borderColor: colors[index % colors.length],
          borderWidth: 1,
          fill: false,
        })),
      },
      options: {
        scales: {
          y: {
            beginAtZero: true,
          },
        },
        responsive: true,
        maintainAspectRatio: false,
        plugins: {
          title: {
            display: true,
            text: "Line Chart",
          },
        },
      },
    });
  }
  
  function drawPieChart(data, fields, container, colors) {
    const canvas = document.createElement("canvas");
    canvas.width = 800;
    canvas.height = 600;
    container.appendChild(canvas);
  
    const ctx = canvas.getContext("2d");
  
    new Chart(ctx, {
      type: "pie",
      data: {
        labels: data.map((item) => item.name),
        datasets: fields.map((fieldName, index) => ({
          label: fieldName,
          data: data.map((item) => item[fieldName]),
          backgroundColor: data.map((_, dataIndex) => colors[dataIndex % colors.length]),
          borderColor: "rgba(255, 255, 255, 1)",
          borderWidth: 2,
        })),
      },
      options: {
        responsive: true,
        maintainAspectRatio: false,
        plugins: {
          title: {
            display: true,
            text: "Pie Chart",
          },
        },
      },
    });
  }
  
  drawChartsForAllFields(healthData);
  