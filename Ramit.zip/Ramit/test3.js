// Matches played over months
const lineGraphData = {
    labels: ["January", "February", "March", "April", "May", "June", "July"],
    datasets: [{
      label: 'Matches Played',
      data: [20, 15, 25, 30, 35, 40, 45],
      fill: false,
      borderColor: 'rgb(75, 192, 192)',
      tension: 0.1
    }]
  };
  
  // Number of goals scored by each team
  const barChartData = {
    labels: ["Team A", "Team B", "Team C", "Team D"],
    datasets: [{
      label: 'Goals Scored',
      data: [50, 40, 35, 45],
      backgroundColor: [
        'rgba(255, 99, 132, 0.2)',
        'rgba(54, 162, 235, 0.2)',
        'rgba(255, 206, 86, 0.2)',
        'rgba(75, 192, 192, 0.2)'
      ],
      borderColor: [
        'rgba(255, 99, 132, 1)',
        'rgba(54, 162, 235, 1)',
        'rgba(255, 206, 86, 1)',
        'rgba(75, 192, 192, 1)'
      ],
      borderWidth: 1
    }]
  };
  
  // Number of wins by each team
  const columnChartData = {
    labels: ["Team A", "Team B", "Team C", "Team D"],
    datasets: [{
      label: 'Wins',
      data: [15, 20, 18, 22],
      backgroundColor: [
        'rgba(255, 99, 132, 0.2)',
        'rgba(54, 162, 235, 0.2)',
        'rgba(255, 206, 86, 0.2)',
        'rgba(75, 192, 192, 0.2)'
      ],
      borderColor: [
        'rgba(255, 99, 132, 1)',
        'rgba(54, 162, 235, 1)',
        'rgba(255, 206, 86, 1)',
        'rgba(75, 192, 192, 1)'
      ],
      borderWidth: 1
    }]
  };
  
  //Distribution of wins among teams
  const pieChartData = {
    labels: ["Team A", "Team B", "Team C", "Team D"],
    datasets: [{
      label: 'Wins',
      data: [25, 20, 15, 30],
      backgroundColor: [
        'rgba(255, 99, 132, 0.2)',
        'rgba(54, 162, 235, 0.2)',
        'rgba(255, 206, 86, 0.2)',
        'rgba(75, 192, 192, 0.2)'
      ],
      borderColor: [
        'rgba(255, 99, 132, 1)',
        'rgba(54, 162, 235, 1)',
        'rgba(255, 206, 86, 1)',
        'rgba(75, 192, 192, 1)'
      ],
      borderWidth: 1
    }]
  };
  
  // Line chart
  var ctxLine = document.getElementById('lineChart').getContext('2d');
  var lineChart = new Chart(ctxLine, {
    type: 'line',
    data: lineGraphData,
  });
  
  // Bar chart
  var ctxBar = document.getElementById('barChart').getContext('2d');
  var barChart = new Chart(ctxBar, {
    type: 'bar',
    data: barChartData,
  });
  
  // Column chart
  var ctxColumn = document.getElementById('columnChart').getContext('2d');
  var columnChart = new Chart(ctxColumn, {
    type: 'bar',
    data: columnChartData,
  });
  
  // Pie chart
  var ctxPie = document.getElementById('pieChart').getContext('2d');
  var pieChart = new Chart(ctxPie, {
    type: 'pie',
    data: pieChartData,
  });